export const queries = ` #graphql
 verifyGoogleToken (token:String!): String
`;
