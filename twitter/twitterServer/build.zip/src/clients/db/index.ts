import { PrismaClient } from "@prisma/client";
//primsa client should've been made here , but root folder has created it so its fine
